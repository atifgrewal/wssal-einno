<?php

return [
    'site_title' => 'wssal',
];
