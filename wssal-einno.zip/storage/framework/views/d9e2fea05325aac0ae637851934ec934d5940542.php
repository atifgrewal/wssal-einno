
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.product.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.products.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.product.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', '')); ?>" required>
                <?php if($errors->has('name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="description"><?php echo e(trans('cruds.product.fields.description')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" name="description" id="description"><?php echo e(old('description')); ?></textarea>
                <?php if($errors->has('description')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('description')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.description_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="sub_category_id"><?php echo e(trans('cruds.product.fields.sub_category')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('sub_category') ? 'is-invalid' : ''); ?>" name="sub_category_id" id="sub_category_id">
                    <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('sub_category_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('sub_category')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('sub_category')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.sub_category_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="tags"><?php echo e(trans('cruds.product.fields.tag')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('tags') ? 'is-invalid' : ''); ?>" name="tags[]" id="tags" multiple>
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(in_array($id, old('tags', [])) ? 'selected' : ''); ?>><?php echo e($tag); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('tags')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tags')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.tag_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.product.fields.featured')); ?></label>
                <select class="form-control <?php echo e($errors->has('featured') ? 'is-invalid' : ''); ?>" name="featured" id="featured">
                    <option value disabled <?php echo e(old('featured', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Product::FEATURED_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('featured', '0') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('featured')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('featured')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.featured_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="regular_price"><?php echo e(trans('cruds.product.fields.regular_price')); ?></label>
                <input class="form-control <?php echo e($errors->has('regular_price') ? 'is-invalid' : ''); ?>" type="number" name="regular_price" id="regular_price" value="<?php echo e(old('regular_price', '')); ?>" step="0.01">
                <?php if($errors->has('regular_price')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('regular_price')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.regular_price_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="sale_price"><?php echo e(trans('cruds.product.fields.sale_price')); ?></label>
                <input class="form-control <?php echo e($errors->has('sale_price') ? 'is-invalid' : ''); ?>" type="number" name="sale_price" id="sale_price" value="<?php echo e(old('sale_price', '')); ?>" step="0.01" required>
                <?php if($errors->has('sale_price')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('sale_price')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.sale_price_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="sku"><?php echo e(trans('cruds.product.fields.sku')); ?></label>
                <input class="form-control <?php echo e($errors->has('sku') ? 'is-invalid' : ''); ?>" type="number" name="sku" id="sku" value="<?php echo e(old('sku', '0')); ?>" step="1" required>
                <?php if($errors->has('sku')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('sku')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.sku_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="qty"><?php echo e(trans('cruds.product.fields.qty')); ?></label>
                <input class="form-control <?php echo e($errors->has('qty') ? 'is-invalid' : ''); ?>" type="number" name="qty" id="qty" value="<?php echo e(old('qty', '1')); ?>" step="1" required>
                <?php if($errors->has('qty')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('qty')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.qty_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="fetaured_image"><?php echo e(trans('cruds.product.fields.fetaured_image')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('fetaured_image') ? 'is-invalid' : ''); ?>" id="fetaured_image-dropzone">
                </div>
                <?php if($errors->has('fetaured_image')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('fetaured_image')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.fetaured_image_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="vendor"><?php echo e(trans('cruds.product.fields.vendor')); ?></label>
                <input class="form-control <?php echo e($errors->has('vendor') ? 'is-invalid' : ''); ?>" type="number" name="vendor" id="vendor" value="<?php echo e(old('vendor', '')); ?>" step="1" required>
                <?php if($errors->has('vendor')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('vendor')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.vendor_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="image"><?php echo e(trans('cruds.product.fields.image')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('image') ? 'is-invalid' : ''); ?>" id="image-dropzone">
                </div>
                <?php if($errors->has('image')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('image')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.image_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="category_id"><?php echo e(trans('cruds.product.fields.category')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('category') ? 'is-invalid' : ''); ?>" name="category_id" id="category_id" required>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('category_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('category')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('category')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.category_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    Dropzone.options.fetauredImageDropzone = {
    url: '<?php echo e(route('admin.products.storeMedia')); ?>',
    maxFilesize: 5, // MB
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 5
    },
    success: function (file, response) {
      $('form').find('input[name="fetaured_image"]').remove()
      $('form').append('<input type="hidden" name="fetaured_image" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="fetaured_image"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($product) && $product->fetaured_image): ?>
      var file = <?php echo json_encode($product->fetaured_image); ?>

          this.options.addedfile.call(this, file)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="fetaured_image" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<script>
    var uploadedImageMap = {}
Dropzone.options.imageDropzone = {
    url: '<?php echo e(route('admin.products.storeMedia')); ?>',
    maxFilesize: 5, // MB
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 5
    },
    success: function (file, response) {
      $('form').append('<input type="hidden" name="image[]" value="' + response.name + '">')
      uploadedImageMap[file.name] = response.name
    },
    removedfile: function (file) {
      file.previewElement.remove()
      var name = ''
      if (typeof file.file_name !== 'undefined') {
        name = file.file_name
      } else {
        name = uploadedImageMap[file.name]
      }
      $('form').find('input[name="image[]"][value="' + name + '"]').remove()
    },
    init: function () {
<?php if(isset($product) && $product->image): ?>
          var files =
            <?php echo json_encode($product->image); ?>

              for (var i in files) {
              var file = files[i]
              this.options.addedfile.call(this, file)
              file.previewElement.classList.add('dz-complete')
              $('form').append('<input type="hidden" name="image[]" value="' + file.file_name + '">')
            }
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\company\einnovention\git_desk\wssal-einno\resources\views/admin/products/create.blade.php ENDPATH**/ ?>