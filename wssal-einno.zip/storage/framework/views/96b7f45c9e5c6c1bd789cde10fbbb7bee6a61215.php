
<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('driver_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.drivers.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.driver.title_singular')); ?>

            </a>
            <button class="btn btn-warning" data-toggle="modal" data-target="#csvImportModal">
                <?php echo e(trans('global.app_csvImport')); ?>

            </button>
            <?php echo $__env->make('csvImport.modal', ['model' => 'Driver', 'route' => 'admin.drivers.parseCsvImport'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.driver.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-Driver">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.email')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.address')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.profile')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.transport')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.transport_image')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.status')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.cnic_no')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.cnic_start_date')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.cnic_expire_date')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.store_name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.account_name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.current_balance')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.iban_no')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.bank_name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.swift_code')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.total_orders')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.total_earning')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.transport_no')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.provider')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.wal_amount')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.phone_no')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.driver.fields.wal_mobile_no')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($driver->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($driver->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->email ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->address ?? ''); ?>

                            </td>
                            <td>
                                <?php if($driver->profile): ?>
                                    <a href="<?php echo e($driver->profile->getUrl()); ?>" target="_blank">
                                        <?php echo e(trans('global.view_file')); ?>

                                    </a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e(App\Models\Driver::TRANSPORT_SELECT[$driver->transport] ?? ''); ?>

                            </td>
                            <td>
                                <?php $__currentLoopData = $driver->transport_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e($media->getUrl()); ?>" target="_blank">
                                        <?php echo e(trans('global.view_file')); ?>

                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php echo e(App\Models\Driver::STATUS_SELECT[$driver->status] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->cnic_no ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->cnic_start_date ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->cnic_expire_date ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->store_name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->account_name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->current_balance ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->iban_no ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->bank_name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->swift_code ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->total_orders ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->total_earning ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->transport_no ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\Driver::PROVIDER_SELECT[$driver->provider] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->wal_amount ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->phone_no ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($driver->wal_mobile_no ?? ''); ?>

                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('driver_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.drivers.show', $driver->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('driver_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.drivers.edit', $driver->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('driver_delete')): ?>
                                    <form action="<?php echo e(route('admin.drivers.destroy', $driver->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                    </form>
                                <?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('driver_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.drivers.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-Driver:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\company\einnovention\git_desk\wssal-einno\resources\views/admin/drivers/index.blade.php ENDPATH**/ ?>