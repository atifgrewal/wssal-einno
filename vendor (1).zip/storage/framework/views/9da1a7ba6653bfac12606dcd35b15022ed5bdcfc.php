<div id="sidebar" class="c-sidebar c-sidebar-fixed c-sidebar-lg-show">

    <div class="c-sidebar-brand d-md-down-none">
        <a class="c-sidebar-brand-full h4" href="#">
            <?php echo e(trans('panel.site_title')); ?>

        </a>
    </div>

    <ul class="c-sidebar-nav">
        <li>
            <select class="searchable-field form-control">

            </select>
        </li>
        <li class="c-sidebar-nav-item">
            <a href="<?php echo e(route("admin.home")); ?>" class="c-sidebar-nav-link">
                <i class="c-sidebar-nav-icon fas fa-fw fa-tachometer-alt">

                </i>
                <?php echo e(trans('global.dashboard')); ?>

            </a>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/permissions*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/users*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-users c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.userManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.permissions.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-unlock-alt c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.permission.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.roles.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/roles") || request()->is("admin/roles/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-briefcase c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.role.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.users.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-user c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.user.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/product-categories*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/sub-cats*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/product-tags*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/products*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/units*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/variations*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/attributes*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/attributedetails*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-shopping-cart c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.productManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_category_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.product-categories.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/product-categories") || request()->is("admin/product-categories/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-folder c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.productCategory.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sub_cat_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.sub-cats.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/sub-cats") || request()->is("admin/sub-cats/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.subCat.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_tag_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.product-tags.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/product-tags") || request()->is("admin/product-tags/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-folder c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.productTag.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.products.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/products") || request()->is("admin/products/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-shopping-cart c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.product.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('unit_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.units.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/units") || request()->is("admin/units/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-chess-bishop c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.unit.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('variation_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.variations.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/variations") || request()->is("admin/variations/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-bullseye c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.variation.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attribute_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.attributes.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/attributes") || request()->is("admin/attributes/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-at c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.attribute.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attributedetail_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.attributedetails.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/attributedetails") || request()->is("admin/attributedetails/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fab fa-amilia c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.attributedetail.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/content-categories*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/content-tags*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/content-pages*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-book c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.contentManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_category_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.content-categories.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/content-categories") || request()->is("admin/content-categories/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-folder c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.contentCategory.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_tag_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.content-tags.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/content-tags") || request()->is("admin/content-tags/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-tags c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.contentTag.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('content_page_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.content-pages.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/content-pages") || request()->is("admin/content-pages/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-file c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.contentPage.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vendor_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.vendors.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/vendors") || request()->is("admin/vendors/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.vendor.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('driver_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.drivers.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/drivers") || request()->is("admin/drivers/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fab fa-dochub c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.driver.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.orders.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/orders") || request()->is("admin/orders/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fab fa-first-order c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.order.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php ($unread = \App\Models\QaTopic::unreadCount()); ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.messenger.index")); ?>" class="<?php echo e(request()->is("admin/messenger") || request()->is("admin/messenger/*") ? "c-active" : ""); ?> c-sidebar-nav-link">
                    <i class="c-sidebar-nav-icon fa-fw fa fa-envelope">

                    </i>
                    <span><?php echo e(trans('global.messages')); ?></span>
                    <?php if($unread > 0): ?>
                        <strong>( <?php echo e($unread); ?> )</strong>
                    <?php endif; ?>

                </a>
            </li>
            <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_password_edit')): ?>
                    <li class="c-sidebar-nav-item">
                        <a class="c-sidebar-nav-link <?php echo e(request()->is('profile/password') || request()->is('profile/password/*') ? 'c-active' : ''); ?>" href="<?php echo e(route('profile.password.edit')); ?>">
                            <i class="fa-fw fas fa-key c-sidebar-nav-icon">
                            </i>
                            <?php echo e(trans('global.change_password')); ?>

                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
            <li class="c-sidebar-nav-item">
                <a href="#" class="c-sidebar-nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                    <i class="c-sidebar-nav-icon fas fa-fw fa-sign-out-alt">

                    </i>
                    <?php echo e(trans('global.logout')); ?>

                </a>
            </li>
    </ul>

</div><?php /**PATH G:\vendor\resources\views/partials/menu.blade.php ENDPATH**/ ?>