<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.vendor.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.vendors.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.vendor.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', '')); ?>" required>
                <?php if($errors->has('name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="business_name"><?php echo e(trans('cruds.vendor.fields.business_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('business_name') ? 'is-invalid' : ''); ?>" type="text" name="business_name" id="business_name" value="<?php echo e(old('business_name', '')); ?>" required>
                <?php if($errors->has('business_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('business_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.business_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.vendor.fields.status')); ?></label>
                <select class="form-control <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>" name="status" id="status" required>
                    <option value disabled <?php echo e(old('status', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Vendor::STATUS_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('status', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('status')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('status')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.status_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.vendor.fields.featured')); ?></label>
                <select class="form-control <?php echo e($errors->has('featured') ? 'is-invalid' : ''); ?>" name="featured" id="featured" required>
                    <option value disabled <?php echo e(old('featured', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Vendor::FEATURED_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('featured', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('featured')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('featured')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.featured_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.vendor.fields.promoted')); ?></label>
                <select class="form-control <?php echo e($errors->has('promoted') ? 'is-invalid' : ''); ?>" name="promoted" id="promoted" required>
                    <option value disabled <?php echo e(old('promoted', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Vendor::PROMOTED_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('promoted', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('promoted')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('promoted')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.promoted_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="email"><?php echo e(trans('cruds.vendor.fields.email')); ?></label>
                <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" required>
                <?php if($errors->has('email')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('email')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.email_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="phone"><?php echo e(trans('cruds.vendor.fields.phone')); ?></label>
                <input class="form-control <?php echo e($errors->has('phone') ? 'is-invalid' : ''); ?>" type="number" name="phone" id="phone" value="<?php echo e(old('phone', '0')); ?>" step="1" required>
                <?php if($errors->has('phone')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('phone')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.phone_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="address"><?php echo e(trans('cruds.vendor.fields.address')); ?></label>
                <input class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" type="text" name="address" id="address" value="<?php echo e(old('address', '')); ?>" required>
                <?php if($errors->has('address')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('address')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.address_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="rating"><?php echo e(trans('cruds.vendor.fields.rating')); ?></label>
                <input class="form-control <?php echo e($errors->has('rating') ? 'is-invalid' : ''); ?>" type="number" name="rating" id="rating" value="<?php echo e(old('rating', '')); ?>" step="0.1" required max="7">
                <?php if($errors->has('rating')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('rating')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.rating_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="payouts"><?php echo e(trans('cruds.vendor.fields.payouts')); ?></label>
                <input class="form-control <?php echo e($errors->has('payouts') ? 'is-invalid' : ''); ?>" type="number" name="payouts" id="payouts" value="<?php echo e(old('payouts', '0')); ?>" step="1" required>
                <?php if($errors->has('payouts')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('payouts')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.payouts_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="earning"><?php echo e(trans('cruds.vendor.fields.earning')); ?></label>
                <input class="form-control <?php echo e($errors->has('earning') ? 'is-invalid' : ''); ?>" type="text" name="earning" id="earning" value="<?php echo e(old('earning', '')); ?>">
                <?php if($errors->has('earning')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('earning')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.earning_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="cod_balance"><?php echo e(trans('cruds.vendor.fields.cod_balance')); ?></label>
                <input class="form-control <?php echo e($errors->has('cod_balance') ? 'is-invalid' : ''); ?>" type="number" name="cod_balance" id="cod_balance" value="<?php echo e(old('cod_balance', '0')); ?>" step="1" required>
                <?php if($errors->has('cod_balance')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('cod_balance')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.cod_balance_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="oniline_payment"><?php echo e(trans('cruds.vendor.fields.oniline_payment')); ?></label>
                <input class="form-control <?php echo e($errors->has('oniline_payment') ? 'is-invalid' : ''); ?>" type="number" name="oniline_payment" id="oniline_payment" value="<?php echo e(old('oniline_payment', '0')); ?>" step="1" required>
                <?php if($errors->has('oniline_payment')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('oniline_payment')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.oniline_payment_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="image"><?php echo e(trans('cruds.vendor.fields.image')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('image') ? 'is-invalid' : ''); ?>" id="image-dropzone">
                </div>
                <?php if($errors->has('image')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('image')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.image_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="cid_expiry_data"><?php echo e(trans('cruds.vendor.fields.cid_expiry_data')); ?></label>
                <input class="form-control date <?php echo e($errors->has('cid_expiry_data') ? 'is-invalid' : ''); ?>" type="text" name="cid_expiry_data" id="cid_expiry_data" value="<?php echo e(old('cid_expiry_data')); ?>" required>
                <?php if($errors->has('cid_expiry_data')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('cid_expiry_data')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.cid_expiry_data_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="cid_no"><?php echo e(trans('cruds.vendor.fields.cid_no')); ?></label>
                <input class="form-control <?php echo e($errors->has('cid_no') ? 'is-invalid' : ''); ?>" type="number" name="cid_no" id="cid_no" value="<?php echo e(old('cid_no', '')); ?>" step="0.01" required>
                <?php if($errors->has('cid_no')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('cid_no')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.cid_no_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="cnic_image"><?php echo e(trans('cruds.vendor.fields.cnic_image')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('cnic_image') ? 'is-invalid' : ''); ?>" id="cnic_image-dropzone">
                </div>
                <?php if($errors->has('cnic_image')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('cnic_image')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.cnic_image_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="account_no"><?php echo e(trans('cruds.vendor.fields.account_no')); ?></label>
                <input class="form-control <?php echo e($errors->has('account_no') ? 'is-invalid' : ''); ?>" type="text" name="account_no" id="account_no" value="<?php echo e(old('account_no', '')); ?>" required>
                <?php if($errors->has('account_no')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('account_no')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.account_no_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="opening_time"><?php echo e(trans('cruds.vendor.fields.opening_time')); ?></label>
                <input class="form-control datetime <?php echo e($errors->has('opening_time') ? 'is-invalid' : ''); ?>" type="text" name="opening_time" id="opening_time" value="<?php echo e(old('opening_time')); ?>" required>
                <?php if($errors->has('opening_time')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('opening_time')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.opening_time_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="closing_time"><?php echo e(trans('cruds.vendor.fields.closing_time')); ?></label>
                <input class="form-control datetime <?php echo e($errors->has('closing_time') ? 'is-invalid' : ''); ?>" type="text" name="closing_time" id="closing_time" value="<?php echo e(old('closing_time')); ?>" required>
                <?php if($errors->has('closing_time')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('closing_time')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.closing_time_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.vendor.fields.business_type')); ?></label>
                <select class="form-control <?php echo e($errors->has('business_type') ? 'is-invalid' : ''); ?>" name="business_type" id="business_type" required>
                    <option value disabled <?php echo e(old('business_type', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Vendor::BUSINESS_TYPE_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('business_type', '0') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('business_type')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('business_type')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.business_type_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="bank_name"><?php echo e(trans('cruds.vendor.fields.bank_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('bank_name') ? 'is-invalid' : ''); ?>" type="text" name="bank_name" id="bank_name" value="<?php echo e(old('bank_name', '')); ?>" required>
                <?php if($errors->has('bank_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('bank_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.bank_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="iban_no"><?php echo e(trans('cruds.vendor.fields.iban_no')); ?></label>
                <input class="form-control <?php echo e($errors->has('iban_no') ? 'is-invalid' : ''); ?>" type="text" name="iban_no" id="iban_no" value="<?php echo e(old('iban_no', '')); ?>" required>
                <?php if($errors->has('iban_no')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('iban_no')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.iban_no_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="swift_code"><?php echo e(trans('cruds.vendor.fields.swift_code')); ?></label>
                <input class="form-control <?php echo e($errors->has('swift_code') ? 'is-invalid' : ''); ?>" type="text" name="swift_code" id="swift_code" value="<?php echo e(old('swift_code', '')); ?>" required>
                <?php if($errors->has('swift_code')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('swift_code')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.vendor.fields.swift_code_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    Dropzone.options.imageDropzone = {
    url: '<?php echo e(route('admin.vendors.storeMedia')); ?>',
    maxFilesize: 5, // MB
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 5
    },
    success: function (file, response) {
      $('form').find('input[name="image"]').remove()
      $('form').append('<input type="hidden" name="image" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="image"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($vendor) && $vendor->image): ?>
      var file = <?php echo json_encode($vendor->image); ?>

          this.options.addedfile.call(this, file)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="image" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<script>
    Dropzone.options.cnicImageDropzone = {
    url: '<?php echo e(route('admin.vendors.storeMedia')); ?>',
    maxFilesize: 2, // MB
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2
    },
    success: function (file, response) {
      $('form').find('input[name="cnic_image"]').remove()
      $('form').append('<input type="hidden" name="cnic_image" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="cnic_image"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($vendor) && $vendor->cnic_image): ?>
      var file = <?php echo json_encode($vendor->cnic_image); ?>

          this.options.addedfile.call(this, file)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="cnic_image" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\company\einnovention\wassal_vendor_App\vendor\vendor\resources\views/admin/vendors/create.blade.php ENDPATH**/ ?>