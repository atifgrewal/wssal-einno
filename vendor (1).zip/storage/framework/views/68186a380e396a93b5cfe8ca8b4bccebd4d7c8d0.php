<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vendor_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.vendors.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.vendor.title_singular')); ?>

            </a>
            <button class="btn btn-warning" data-toggle="modal" data-target="#csvImportModal">
                <?php echo e(trans('global.app_csvImport')); ?>

            </button>
            <?php echo $__env->make('csvImport.modal', ['model' => 'Vendor', 'route' => 'admin.vendors.parseCsvImport'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.vendor.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-Vendor">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.business_name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.status')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.featured')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.promoted')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.email')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.phone')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.address')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.rating')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.payouts')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.earning')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.cod_balance')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.oniline_payment')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.image')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.cid_expiry_data')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.cid_no')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.cnic_image')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.account_no')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.opening_time')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.closing_time')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.business_type')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.bank_name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.iban_no')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.vendor.fields.swift_code')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($vendor->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($vendor->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($vendor->name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($vendor->business_name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\Vendor::STATUS_SELECT[$vendor->status] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\Vendor::FEATURED_SELECT[$vendor->featured] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\Vendor::PROMOTED_SELECT[$vendor->promoted] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($vendor->email ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($vendor->phone ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($vendor->address ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($vendor->rating ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($vendor->payouts ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($vendor->earning ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($vendor->cod_balance ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($vendor->oniline_payment ?? ''); ?>

                            </td>
                            <td>
                                <?php if($vendor->image): ?>
                                    <a href="<?php echo e($vendor->image->getUrl()); ?>" target="_blank">
                                        <?php echo e(trans('global.view_file')); ?>

                                    </a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($vendor->cid_expiry_data ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($vendor->cid_no ?? ''); ?>

                            </td>
                            <td>
                                <?php if($vendor->cnic_image): ?>
                                    <a href="<?php echo e($vendor->cnic_image->getUrl()); ?>" target="_blank">
                                        <?php echo e(trans('global.view_file')); ?>

                                    </a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($vendor->account_no ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($vendor->opening_time ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($vendor->closing_time ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\Vendor::BUSINESS_TYPE_SELECT[$vendor->business_type] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($vendor->bank_name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($vendor->iban_no ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($vendor->swift_code ?? ''); ?>

                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vendor_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.vendors.show', $vendor->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vendor_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.vendors.edit', $vendor->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vendor_delete')): ?>
                                    <form action="<?php echo e(route('admin.vendors.destroy', $vendor->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                    </form>
                                <?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vendor_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.vendors.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-Vendor:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\company\einnovention\wassal_vendor_App\vendor\vendor\resources\views/admin/vendors/index.blade.php ENDPATH**/ ?>