<?php

namespace App\Http\Controllers\Admin;

use App\Models\Driver;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\SubCat;
use App\Models\User;
use App\Models\Vendor;

class HomeController
{
    public function index()
    {
       $data=User::with(['roles'])->where('id',2)->get();
        //  dd($data1);
        $data2=Driver::all();
        // dd($data2);
         $data1=ProductCategory::all();
        //   dd($data1);
        $data3=Product::all();
        // dd($data3);
        $data4=Vendor::all();
    //    dd($data);
    $data5=SubCat::all();
    // dd($data5);
        return view('home',compact('data','data1','data2','data3','data4',
    'data5'));
    }
}
